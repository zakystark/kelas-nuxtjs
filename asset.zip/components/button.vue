<template>
  <button class="p-2 bg-slate-600 text-white rounded-lg">
    Click me!
  </button>
</template>
<!-- components/Footer.vue -->
<template>
    <footer class="footer">
      <p><Al-kademi></Al-kademi></p>
    </footer>
  </template>
  
  <script>
  export default {
    name: 'Footer',
  }
  </script>
  
  <style scoped>
  .footer {
    background-color: #333;
    color: white;
    text-align: center;
    padding: 1rem;
    position: absolute;
    bottom: 0;
    width: 100%;
  }
  </style>
  
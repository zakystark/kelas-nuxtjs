<template>
 <NuxtLayout>
  <h1 class="text-3xl font-bold underline">
    zaky zain
  </h1>
  <Button />
  <NuxtPage />
  </NuxtLayout>
</template>
